package com.coptic.dailyverse.data
import java.util.Calendar
object CopticCalendar {
    private val months = listOf("توت","بابه","هاتور","كيهك","طوبة","أمشير","برمهات","برمودة","بشنس","بؤونة","أبيب","مسرى","النسئ")
    fun getToday(): String {
        val c = Calendar.getInstance()
        val jd = (1461 * (c.get(Calendar.YEAR) + 4800 + (c.get(Calendar.MONTH)-14)/12))/4 + (367 * (c.get(Calendar.MONTH) - 2 - 12 * ((c.get(Calendar.MONTH)-14)/12)))/12 - (3 * ((c.get(Calendar.YEAR)+4900+(c.get(Calendar.MONTH)-14)/12)/100))/4 + c.get(Calendar.DAY_OF_MONTH) - 32075
        val copticJD = jd - 1825029
        val year = copticJD / 365
        val dayOfYear = copticJD % 365
        val month = dayOfYear / 30
        val day = dayOfYear % 30 + 1
        return "${day} ${months[month.coerceIn(0,12)]} ${1684 + year/365} للشهداء"
    }
}
